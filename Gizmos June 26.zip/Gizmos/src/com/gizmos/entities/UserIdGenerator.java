package com.gizmos.entities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;
import org.springframework.beans.factory.annotation.Autowired;

public class UserIdGenerator implements IdentifierGenerator {
	
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object arg1) throws HibernateException {
		String strId=null;
		String zeroAppend="";
		
		try {
			int nextVal = getNextValueFromSequence(session);
			strId = String.valueOf(nextVal);
			int strLen = strId.length();
			if (strId.length()<3){
				for(int idx=1; idx<= 3-strLen; idx++){
					zeroAppend += "0";
				}
			}
			//autoId++;
		} catch (SQLException e) {
			e.printStackTrace();
		}
        return "User"+ zeroAppend + strId;
	}
	
	 private int getNextValueFromSequence(SharedSessionContractImplementor session) throws SQLException{
	    	Connection connect = session.connection();
	    	int nextVal = 0;
	    	Statement stmt = connect.createStatement();
	    	ResultSet rs = stmt.executeQuery("select UserIdSeq.nextval from Dual");
	    	if (rs.next()){
	    		nextVal = rs.getInt(1);
	    		
	    	}
	    	
	    	return nextVal;
	    }



	

}
