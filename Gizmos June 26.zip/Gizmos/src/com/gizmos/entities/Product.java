package com.gizmos.entities;

import javax.persistence.*;


@Entity(name="Product")
@Table(name="PRODUCTS")
public class Product {

	@Id
	@Column(name="prodid")
	private String productId;
	
	@Column(name="prodname")
	private String productName;
	
	@Column(name="prodprice")
	private String productPrice;
	
	@Column(name="proddesc")
	private String productDescription;
	
	@Column(name="qty")
	private int quantity;
	
	@Column(name="brand")
	private String productBrand;
	
	@Column(name="catid")
	private String categoryId;
	
	@Column(name="pic_name")
	private String productPic;
	
	public Product() {
		super();
	}
	

	public Product(String productId, String productName, String productPrice, String productDescription, int quantity,
			String productBrand, String categoryId, String productPic) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.quantity = quantity;
		this.productBrand = productBrand;
		this.categoryId = categoryId;
		this.productPic = productPic;
	}




	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	
	public String getProductPic() {
		return productPic;
	}


	public void setProductPic(String productPic) {
		this.productPic = productPic;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productDescription=" + productDescription + ", quantity=" + quantity + ", productBrand="
				+ productBrand + ", categoryId=" + categoryId + ", productPic=" + productPic + "]";
	}
	
}
