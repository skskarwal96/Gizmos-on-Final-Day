package com.gizmos.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity(name="Orders")
@Table(name="ORDERTABLE")
public class Orders {
	
	
	@Id
	@Column(name = "ORDERID")
	private String orderId;
	
	@Column(name = "USERID")
	private String buyerId;
	
	@Column(name = "ADDR")
	private String buyerAddress;
	
	@Column(name = "CITY")
	private String buyerCity;
	
	@Column(name = "ZIP")
	private int buyerZipNo;
	
	@Column(name = "STATE")
	private String buyerState;
	
	@Column(name = "MODEPAY")
	private String modeOfPayment;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "DATEPUR")
	private Date dateOfPurchase;
	
	@Column(name = "PRODID")
	private String productId;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "DELIVERYDATE")
	private Date deliveryDate;
	
	@Column(name = "NOITEM")
	private int noOfItemsPurchased;
	
	@Column(name = "TOTALAMT")
	private int totalBillAmount;
	
	
	public Orders() {
		super();
	}
	
	
	public Orders(String orderId, String buyerId, String buyerAddress, String buyerCity, int buyerZipNo,
			String buyerState, String modeOfPayment, Date dateOfPurchase, String productId, Date deliveryDate,
			int noOfItemsPurchased, int totalBillAmount) {
		super();
		this.orderId = orderId;
		this.buyerId = buyerId;
		this.buyerAddress = buyerAddress;
		this.buyerCity = buyerCity;
		this.buyerZipNo = buyerZipNo;
		this.buyerState = buyerState;
		this.modeOfPayment = modeOfPayment;
		this.dateOfPurchase = dateOfPurchase;
		this.productId = productId;
		this.deliveryDate = deliveryDate;
		this.noOfItemsPurchased = noOfItemsPurchased;
		this.totalBillAmount = totalBillAmount;
	}
	
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getBuyerAddress() {
		return buyerAddress;
	}
	public void setBuyerAddress(String buyerAddress) {
		this.buyerAddress = buyerAddress;
	}
	public String getBuyerCity() {
		return buyerCity;
	}
	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}
	public int getBuyerZipNo() {
		return buyerZipNo;
	}
	public void setBuyerZipNo(int buyerZipNo) {
		this.buyerZipNo = buyerZipNo;
	}
	public String getBuyerState() {
		return buyerState;
	}
	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public Date getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(Date dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public int getNoOfItemsPurchased() {
		return noOfItemsPurchased;
	}
	public void setNoOfItemsPurchased(int noOfItemsPurchased) {
		this.noOfItemsPurchased = noOfItemsPurchased;
	}
	public int getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(int totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}


	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", buyerId=" + buyerId + ", buyerAddress=" + buyerAddress + ", buyerCity="
				+ buyerCity + ", buyerZipNo=" + buyerZipNo + ", buyerState=" + buyerState + ", modeOfPayment="
				+ modeOfPayment + ", dateOfPurchase=" + dateOfPurchase + ", productId=" + productId + ", deliveryDate="
				+ deliveryDate + ", noOfItemsPurchased=" + noOfItemsPurchased + ", totalBillAmount=" + totalBillAmount
				+ "]";
	}
	
	
	
}
