package com.gizmos.services;


import java.util.Date;
import java.util.List;

import com.gizmos.entities.Orders;
import com.gizmos.exceptions.GizmosException;

public interface OrdersServices {
	List<Orders> viewOrders() throws GizmosException;
	public List<Orders> searchOrdersByDateOfPurchase(Date dateOfPurchase) throws GizmosException;
	void close() throws GizmosException;

}
