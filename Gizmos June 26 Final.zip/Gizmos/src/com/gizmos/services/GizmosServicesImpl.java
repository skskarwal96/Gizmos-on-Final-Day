package com.gizmos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gizmos.daos.GizmosDao;
import com.gizmos.entities.Customer;
import com.gizmos.entities.Product;
import com.gizmos.entities.Specifications;
import com.gizmos.exceptions.GizmosException;

@Service("gizmosServices")
public class GizmosServicesImpl implements GizmosServices {

	@Autowired
	private GizmosDao dao;
	
	@Override
	public List<Product> viewProduct() throws GizmosException {
	
		return dao.viewProduct();
	}
	
	@Override
	public List<Product> searchProductByName(String productName) throws GizmosException {
		
		return dao.searchProductByName(productName);
	}

	@Override
	public void close() throws GizmosException {
		dao.close();
		
	}
	
	@Override
	public List<Product> searchProductByCategory(String categoryName) throws GizmosException {
		
		return dao.searchProductByCategory(categoryName);
	}
	
	@Override
	public List<Customer> viewCustomer() throws GizmosException {
	
		return dao.viewCustomer();
	}
	
	@Override
	public void insertNewProduct(Product product) throws GizmosException {
		dao.insertNewProduct(product);
		
	}

	@Override
	public void deleteByProductId(String productId) throws GizmosException {
		dao.deleteByProductId(productId);
		
	}

	@Override
	public void updateByProductId(Product product) throws GizmosException {
		dao.updateByProductId(product);
		
	}

	@Override
	public List<Specifications> viewSpecifications(String productId) throws GizmosException {
		return dao.viewSpecifications(productId);
	}

}
