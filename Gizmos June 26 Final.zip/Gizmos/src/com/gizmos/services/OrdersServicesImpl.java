package com.gizmos.services;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.gizmos.daos.OrdersDao;
import com.gizmos.entities.Orders;

import com.gizmos.exceptions.GizmosException;


@Service("ordersServices")
public class OrdersServicesImpl implements OrdersServices {

	
	@Autowired
	private OrdersDao dao;
	
	@Override
	public List<Orders> viewOrders() throws GizmosException {
		return dao.viewOrders();
	}

	@Override
	public void close() throws GizmosException {
		dao.close();

	}

	@Override
	public List<Orders> searchOrdersByDateOfPurchase(Date dateOfPurchase) throws GizmosException {
		return dao.searchOrdersByDateOfPurchase(dateOfPurchase);
	}

}
