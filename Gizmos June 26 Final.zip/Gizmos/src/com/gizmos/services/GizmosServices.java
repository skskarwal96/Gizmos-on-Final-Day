package com.gizmos.services;

import java.util.List;

import com.gizmos.entities.Customer;
import com.gizmos.entities.Product;
import com.gizmos.entities.Specifications;
import com.gizmos.exceptions.GizmosException;

public interface GizmosServices {

	
	List<Product> viewProduct() throws GizmosException;

	void close() throws GizmosException;
	
	public List<Product> searchProductByName(String productName) throws GizmosException;
	
	public List<Product> searchProductByCategory(String categoryName) throws GizmosException;
	
	List<Customer> viewCustomer() throws GizmosException;
	
	public void insertNewProduct(Product product) throws GizmosException;
	
	public void deleteByProductId(String productId) throws GizmosException;
	
	public void updateByProductId(Product product) throws GizmosException;
	
	List<Specifications> viewSpecifications(String productId) throws GizmosException;
}
