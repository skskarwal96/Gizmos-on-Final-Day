package com.gizmos.daos;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gizmos.entities.Customer;
import com.gizmos.entities.Product;
import com.gizmos.entities.Specifications;
import com.gizmos.exceptions.GizmosException;

@Repository("gizmosDao")
public class GizmosDaoImpl implements GizmosDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Product> viewProduct() throws GizmosException {

		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Product");
		List<Product> list = qry.list();
		session.close();
		return list;
		
	}
	
	@Override
	public List<Product> searchProductByName(String productName) throws GizmosException {

		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Product p WHERE upper(p.productName)=:product").setParameter("product", productName.toUpperCase());
		List<Product> product = qry.list();
		session.close();
		return product;
		
	}
	
	@Override
	public List<Product> searchProductByCategory(String categoryName) throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Product p WHERE p.categoryId in (SELECT c.categoryId FROM Category c WHERE c.categoryName=:name)").setParameter("name", categoryName);
		List<Product> product = qry.list();
		session.close();
		return product;
	}

	@Override
	public List<Customer> viewCustomer() throws GizmosException {

		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Customer");
		List<Customer> list = qry.list();
		session.close();
		return list;
	}
	
	@Override
	public void close() throws GizmosException {
		
	}
	
	@Override
	public void insertNewProduct(Product product) throws GizmosException{
		Session session=sessionFactory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.save(product);
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
		session.close();
		
	}

	
	@Override
	public void deleteByProductId(String productId) throws GizmosException{
		Session session = sessionFactory.openSession();
	    String hql = "delete Product p where p.productId = :id";
	    Query q = session.createQuery(hql).setParameter("id", productId);
	    Transaction tn = session.getTransaction();
	    try {
			tn.begin();
			q.executeUpdate();
			session.flush();
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
	 
	    session.close();
	}
	@Override
	public void updateByProductId(Product product) throws GizmosException{
		Session session = sessionFactory.openSession();
	    String hql = "update Product p set p.productName =: productName, p.productPrice = :productPrice, p.productDescription =: productDescription, p.quantity =: quantity, p.productBrand =: productBrand where p.productId = :id";
	    Query q = session.createQuery(hql);
	    q.setParameter("id", product.getProductId());
	    q.setParameter("productName", product.getProductName());
	    q.setParameter("productPrice", product.getProductPrice());
	    q.setParameter("productDescription", product.getProductDescription());
	    q.setParameter("quantity", product.getQuantity());
	    q.setParameter("productBrand", product.getProductBrand());
	   
	    
	    Transaction tn = session.getTransaction();
	    try {
			tn.begin();
			q.executeUpdate();
			session.flush();
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
	 
	    session.close();
	}

	@Override
	public List<Specifications> viewSpecifications(String productId) throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Specifications s WHERE s.productId=:productId").setParameter("productId", productId);
		List<Specifications> specs = qry.list();
		session.close();
		return specs;
	}

}
