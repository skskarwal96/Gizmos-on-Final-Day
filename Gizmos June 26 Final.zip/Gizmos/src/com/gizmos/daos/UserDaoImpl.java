package com.gizmos.daos;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;


@Repository("userDao")
public class UserDaoImpl implements UserDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insertNewUser(User user) throws GizmosException {
		Session session=sessionFactory.openSession();



		System.out.println("User: "+user);
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(user);
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
		session.close();
		
	}

	

	@Override
	public void updateByEmailId(User user) throws GizmosException {
		Session session = sessionFactory.openSession();
	    String hql = "update User u set u.userFirstName =: userFirstName, u.userLastName = :userLastName, u.userAddress =: userAddress, u.userCity =: userCity, u.userZipNo =: userZipNo, u.userState =:userState, u.userMobileNo =:userMobileNo where u.userEmail = :email";
	    Query q = session.createQuery(hql);
	    q.setParameter("email", user.getUserEmail());
	    q.setParameter("userFirstName", user.getUserFirstName());
	    q.setParameter("userLastName", user.getUserLastName());
	    q.setParameter("userAddress", user.getUserAddress());
	    q.setParameter("userCity", user.getUserCity());
	    q.setParameter("userZipNo", user.getUserZipNo());
	    q.setParameter("userState", user.getUserState());
	    q.setParameter("userMobileNo", user.getUserMobileNo());
	   
	    
	    Transaction tn = session.getTransaction();
	    try {
			tn.begin();
			q.executeUpdate();
			session.flush();
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
	 
	    session.close();
		
	}
	



	@Override
	public ArrayList<User> viewAccounts() throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("from User u");
		ArrayList<User> list =(ArrayList<User>)qry.list();
		session.close();
		return list;
	
		
	}

    @Override
    public void close() throws GizmosException {
	// TODO Auto-generated method stub
	
    }



	@Override
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM User u WHERE u.dateOfSignUp =: date").setParameter("date", dateOfSignUp);
		List<User> accounts = qry.list();
		session.close();
		return accounts;
	}



	@Override
	public User authenticateUser(String email , String password) throws GizmosException {
//		System.out.println(email+ " in auth !!!");
//		System.out.println(password+ " in auth !!!");
		 Session session = sessionFactory.openSession();
	        Criteria criteria = session.createCriteria(User.class);
	        criteria.add(Restrictions.eq("userEmail", email));
	        criteria.add(Restrictions.eq("userPassword", password));
	        return (User) criteria.uniqueResult();
	}



	@Override
	public List<User> getCustomerData(String email) throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM User u WHERE u.userEmail =: email").setParameter("email", email);
		List<User> userdata = qry.list();
		session.close();
		return userdata;
	}




}
