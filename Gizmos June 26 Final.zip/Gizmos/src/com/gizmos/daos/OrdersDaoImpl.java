package com.gizmos.daos;


import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gizmos.entities.Orders;
import com.gizmos.entities.Product;
import com.gizmos.exceptions.GizmosException;

@Repository("ordersDao")
public class OrdersDaoImpl implements OrdersDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Orders> viewOrders() throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Orders");
		List<Orders> list = qry.list();
		session.close();
		return list;
	}

	@Override
	public void close() throws GizmosException {
		

	}

	@Override
	public List<Orders> searchOrdersByDateOfPurchase(Date dateOfPurchase) throws GizmosException {
		Session session = sessionFactory.openSession();
		Query qry = session.createQuery("FROM Orders o WHERE o.dateOfPurchase =: date").setParameter("date", dateOfPurchase);
		List<Orders> orders = qry.list();
		session.close();
		return orders;
	}

}
