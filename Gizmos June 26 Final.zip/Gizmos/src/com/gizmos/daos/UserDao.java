package com.gizmos.daos;


import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;

public interface UserDao {
	void insertNewUser(User user) throws GizmosException;
	public void updateByEmailId(User user) throws GizmosException;
	ArrayList<User> viewAccounts() throws GizmosException;
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException;
	public User authenticateUser(String email , String password) throws GizmosException;
	public List<User> getCustomerData(String email) throws GizmosException;
	void close() throws GizmosException;
}
