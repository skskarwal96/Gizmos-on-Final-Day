var shopModule = angular.module("shopModule", ['ngRoute','ngCookies','angularUtils.directives.dirPagination']);

shopModule.config(function($routeProvider) {
    $routeProvider
        .when('/homeVisitor',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/home_visitor.htm'
        })
        .when('/contactUs',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/ContactUs.htm'
        })
        .when('/terms',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/TermsAndConditions.htm'
        })
        .when('/payments',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/payments.htm'
        })
        .when('/aboutus',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/aboutus.htm'
        })
        .when('/cartempty',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/cartempty.htm'
        })
        .when('/orders',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/orders.htm'
        })
        .when('/catMobile',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/mobiles.htm'
        })
        .when('/catLaptop',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/laptops.htm'
        })
        .when('/catRefri',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/refrigerators.htm'
        })
        .when('/catAc',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/airconditioners.htm'
        })
        .when('/catTelevision',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/televisions.htm'
        })
        .when('/catCamera',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/cameras.htm'
        })
        .when('/vcatMobile',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/mobiles.htm'
        })
        .when('/vcatLaptop',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/laptops.htm'
        })
        .when('/vcatRefri',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/refrigerators.htm'
        })
        .when('/vcatAc',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/airconditioners.htm'
        })
        .when('/vcatTelevision',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/televisions.htm'
        })
        .when('/vcatCamera',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/cameras.htm'
        })
        .when('/searchResult',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/searchResult.htm'
        })
        .when('/cart',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/user/cart.htm'
        })
        .when('/homeUser',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/user/home_user.htm'
        })
        .when('/paymentGateway',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/user/paymentGateway.htm'
        })
        .when('/billgeneration',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/user/billgeneration.htm'
        })
        .when('/productDescription',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/user/productDescription.htm'
        })
         .when('/vproductDescription',
        {
            controller: 'shopCtrl',
            templateUrl: 'partialviews/visitor/productDescription.htm'
        })
        .otherwise({
            redirectTo: '/homeVisitor'
        });
})
shopModule.controller('shopCtrl', function ($scope, $http, $rootScope,$window) {
   
	$scope.forms = {

			userPassword : "",
			userFirstName : "",
			userLastName : "",
			userAddress : "",
			userCity : "",
			userZipNo : "",
			userState : "",
			userMobileNo : "",
			userEmail : "",
		
		};

	$scope.addUser=function(){
		
		$http({
			method:'POST',
			url:'http://localhost:8081/Gizmos/product/create/'+$scope.forms.userPassword+'/'+$scope.forms.userFirstName+'/'+$scope.forms.userLastName+'/'+$scope.forms.userAddress+'/'+$scope.forms.userCity+'/'+$scope.forms.userZipNo+'/'+$scope.forms.userState+'/'+$scope.forms.userEmail+'/'+$scope.forms.userMobileNo
		}).success(function(data)
				{
				
				alert("You're now a member of Gizmos Family. Please Login.");	
				window.location("http://localhost:8081/Gizmos/#/homeUser/")
				});
		
	}
	$scope.loginform = {

			userPassword : "",
			userEmail : "",
		};
	
	function getCustomerData(email,pass)
	{	
		$scope.email=email;
		$scope.pass=pass;

		 $http({
			 method: 'GET',
			 url:'http://localhost:8081/Gizmos/product/getCustomerData/'+$scope.email+'/'+$scope.pass
		 }).success(function(data){
			 //alert("success Data " + data)
			 $rootScope.customerData= data;
			 console.log($rootScope.customerData.fName);

		 })
		
	}
	$scope.authenticateUser= function()
	 {

		 $http({
			 method: 'POST',
			 url:'http://localhost:8081/Gizmos/product/authenticate/'+$scope.loginform.userEmail+'/'+$scope.loginform.userPassword
		 }).success(function(data){
			 

			if(data==1){
				alert("Login Successful")
			if($scope.loginform.userEmail=="admin@gmail.com" && $scope.loginform.userPassword=="Admin123") {
				 
				 $window.location.href='http://localhost:8081/Gizmos/indexAdmin.htm';
			 }
			else{	
				getCustomerData($scope.loginform.userEmail,$scope.loginform.userPassword);
				$window.location.href='http://localhost:8081/Gizmos/index.htm#/homeUser';
			}
			}
			else{
				alert("Login Fail, Please Retry")
			}

		 })
	 }
	
	
	
})




shopModule.controller("ServiceController",['$scope', '$http', '$rootScope', '$cookies', function($scope, $http, $rootScope, $cookies) {
	
	_refreshPageData();
	function _refreshPageData() {		
		$http(		
				{
					method : 'GET',
					url : 'http://localhost:8081/Gizmos/product/viewProduct.json'
				}
			  ).success(function(data) {
						$scope.products = data;  
						
			});
		
	}
	
	$scope.productByCategory=function(category){
		
		
		$scope.catname = category;
		$http({
			method:'GET',
			url:'http://localhost:8081/Gizmos/product/viewProductByCategory/'+$scope.catname
		}).success(function(data)
				{
					$rootScope.productByCat = data; 

				});
		
		
}

	$scope.getSpecifications=function(productId){
		
		$scope.product = productId;
		$http({
			method:'GET',
			url:'http://localhost:8081/Gizmos/product/viewSpecifications/'+$scope.product
		}).success(function(data)
				{
					$rootScope.specifics = data; 
				});
		
		
}
	

	$scope.cart = [];
	$scope.total = 0;
	
	if(!angular.isUndefined($cookies.get('total'))){
	  $scope.total = parseFloat($cookies.get('total'));
	}

	if (!angular.isUndefined($cookies.get('cart'))) {
	 		$scope.cart =  $cookies.getObject('cart');
	}
	
	$scope.addItemToCart = function(product){

		if ($scope.cart.length === 0){
	 		product.count = 1;
	 		$scope.cart.push(product);
	 	} else {
	 		var repeat = false;
	 		for(var i = 0; i< $scope.cart.length; i++){
	 			if($scope.cart[i].productId === product.productId){
	 				repeat = true;
	 				$scope.cart[i].count +=1;
	 			}
	 		}
	 		if (!repeat) {
	 			product.count = 1;
	 		 	$scope.cart.push(product);	
	 		}
	 	}
	 	var expireDate = new Date();
  expireDate.setDate(expireDate.getDate() + 1);
	 	$cookies.putObject('cart', $scope.cart,  {'expires': expireDate});
	 	$scope.cart = $cookies.getObject('cart');
	 
	  $scope.total += parseFloat(product.productPrice);
  $cookies.put('total', $scope.total,  {'expires': expireDate});
	 };

	 $scope.removeItemCart = function(product){
	   
	   if(product.count > 1){
	     product.count -= 1;
	     var expireDate = new Date();
     expireDate.setDate(expireDate.getDate() + 1);
	     $cookies.putObject('cart', $scope.cart, {'expires': expireDate});
			   $scope.cart = $cookies.getObject('cart');
	   }
	   else if(product.count === 1){
	     var index = $scope.cart.indexOf(product);
			 $scope.cart.splice(index, 1);
			 expireDate = new Date();
   expireDate.setDate(expireDate.getDate() + 1);
			 $cookies.putObject('cart', $scope.cart, {'expires': expireDate});
			 $scope.cart = $cookies.getObject('cart');
	     
	   }
	   
	   $scope.total -= parseFloat(product.productPrice);
   $cookies.put('total', $scope.total,  {'expires': expireDate});
	   
	 };

	 $scope.remove = function(product){

		var index = $scope.cart.indexOf(product);
			 $scope.cart.splice(index, 1);
			 expireDate = new Date();
   expireDate.setDate(expireDate.getDate() + 1);
			 $cookies.putObject('cart', $scope.cart, {'expires': expireDate});
		  $scope.cart = $cookies.getObject('cart');
		  
		  $scope.total -= parseFloat(product.productPrice*product.count );
		  $cookies.put('total', $scope.total,  {'expires': expireDate});  
	 }
	$rootScope.cartt = $scope.cart;
	 
}]);

shopModule.controller("ProductNameController",function($scope, $http, $rootScope,$location) {

	    $scope.prodname="";

	    $scope.productByName=function(){
		
		$http({
			method:'GET',
			url:'http://localhost:8081/Gizmos/product/viewProductByName/'+$scope.prodname
		}).success(function(data)
				{
					$rootScope.productByName1 = data; 

				});
}
});
