var adminModule = angular.module("adminModule", ['ngRoute']);

adminModule.config(function($routeProvider) {
    $routeProvider
        .when('/products',
        {
            controller: 'ServiceController',
            templateUrl: 'partialviews/admin/product.htm'
        })
        .when('/users',
        {
            controller: 'ServiceController',
            templateUrl: 'partialviews/admin/users.htm'
        })
        .when('/orders',
        {
            controller: 'ServiceController',
            templateUrl: 'partialviews/admin/orders.htm'
        })
        .when('/add',
        {
            controller: 'ServiceController',
            templateUrl: 'partialviews/admin/addproduct.htm'
        })
        
        .otherwise({
            redirectTo: 'products'
        });
})



adminModule.controller("ServiceController", function($scope, $http,  $rootScope) {
	
	$('#datepicker').datepicker({
    	format: 'dd-mm-yyyy',
    	uiLibrary: 'bootstrap', 
    	});
	_refreshPageData();
	function _refreshPageData() {	
		
		 
		 
		$http(		
				{
					method : 'GET',
					url : 'http://localhost:8081/Gizmos/product/viewProduct.json'
				}
			  ).success(function(data) {
						$scope.products = data;  
			});
		
	}
	
	$scope.viewOrder= function() {	
		
		$http(		
				{
					method : 'GET',
					url : 'http://localhost:8081/Gizmos/product/viewOrder.json'
				}
			  ).success(function(data) {
			  			
						$rootScope.orders = data;
			   

				 
			});
		
		
		
	}
	
	
	
$scope.viewUser = function(){
	
	$http(		
			{
				method : 'GET',
				url : 'http://localhost:8081/Gizmos/product/viewUser.json'
			}
		  ).success(function(data) {
		  						  		
					$rootScope.users = data;
		});
	
}

$scope.remove=function(data){
	
		console.log(data);

	$http({
		method:'DELETE',
		url:'http://localhost:8081/Gizmos/product/delete/'+data
		
	}).success(function(data)
			{
			alert('Data Deleted')	
			 _refreshPageData();
			
			});
	
}


$scope.form = {
		productId:"",
		productName:"",
		productPrice:"",
		productDescription:"",
		quantity:"",
		productBrand:"",
		categoryId:"",
		productPic:""
	
	};

 $scope.add=function(){
	 
	 $scope.p=$('#imageName').val();
	 $scope.len=$scope.p.length-$scope.p.lastIndexOf("\\");
	 $scope.form.productPic=$scope.p.substr($scope.p.lastIndexOf("\\"),$scope.len);
	 
	
	
	$http({
		method:'POST',
		url:'http://localhost:8081/Gizmos/product/create/'+$scope.form.productId+'/'+$scope.form.productName+'/'+$scope.form.productPrice
		+'/'+$scope.form.productDescription+'/'+$scope.form.quantity+'/'+$scope.form.productBrand+'/'+$scope.form.productPic+'/'+$scope.form.categoryId
	}).success(function(data)
			{
			alert("DATA ADDED");
			window.location.replace("#/products");
			})
}


 $scope.searchOrderByDate=function(){

	 $scope.sdate=datepicker.value;	
	 
	 console.log($scope.sdate);
	 
		
		$http({
			method:'GET',
			url:'http://localhost:8081/Gizmos/product/searchOrder/'+$scope.sdate
		}).success(function(data)
				{
				
				$scope.orders=data;
				});
	}
 
 
 $scope.searchUserByDate=function(){
 $scope.sdate=datepicker.value;	
	 
	 console.log($scope.sdate);
		 
			
			$http({
				method:'GET',
				url:'http://localhost:8081/Gizmos/product/searchUser/'+$scope.sdate
			}).success(function(data)
					{
					
					$scope.users=data;
					});
		}
 
 
});
